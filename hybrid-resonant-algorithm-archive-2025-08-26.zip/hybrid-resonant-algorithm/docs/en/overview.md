# HRA — English Overview

This repository implements a *skeleton* for the Hybrid Resonant Algorithm (HRA):
- Resonance-based search across domains
- Hybrid ML control loop (Generator → Resonance → RL update)
- Embedded ethics sandbox with gating by Γ

> The full Russian technical report is in `../ru/report.md`.
