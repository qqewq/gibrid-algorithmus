from hra import HRA, ResonanceConfig, EthicsBox

if __name__ == "__main__":
    cfg = ResonanceConfig(dim=20, threshold=0.7)
    hra = HRA(config=cfg, ethics=EthicsBox(min_level=0.2))

    suggestion = hra.propose({"domain":"biomed", "goal":"reduce_oxidative_stress"})
    score = hra.resonance(suggestion, {"D":3.2, "q":[1.0,0.4,0.2], "m":[1.0,1.2,1.1]})
    if hra.ethics.ok(score):
        print("Applying:", hra.apply(suggestion))
    else:
        print("Rejected by EthicsBox, score=", score)
