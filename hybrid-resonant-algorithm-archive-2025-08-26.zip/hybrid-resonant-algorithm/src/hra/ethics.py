class EthicsBox:
    def __init__(self, min_level: float = 0.2):
        self.min_level = min_level

    def ok(self, resonance_value: float) -> bool:
        # Minimal gating rule; real implementation would monitor Γ and sandbox maturity
        return resonance_value >= self.min_level
