"""
Hybrid Resonant Algorithm (HRA)
"""
from .core import HRA, ResonanceConfig
from .ethics import EthicsBox
from .resonance import resonance_score
